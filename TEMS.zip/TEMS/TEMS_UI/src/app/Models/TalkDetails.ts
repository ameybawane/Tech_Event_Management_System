export interface ITalkDetails {
    id: number,
    duration: string,
    endTime: Date,
    startTime: Date,
    tags: string,
    title: string,
}


