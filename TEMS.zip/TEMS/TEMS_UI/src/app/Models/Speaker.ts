export interface ISpeaker {
    id: number,
    name: string,
    description: string,
    organisation: string,
    linkedinUrl: string,
    twitterHandle: string
}