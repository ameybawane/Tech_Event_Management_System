export interface IVenue {
    id: number,
    name: string,
    city: string,
    address: string,
    website: string,
    contactNo: string
}