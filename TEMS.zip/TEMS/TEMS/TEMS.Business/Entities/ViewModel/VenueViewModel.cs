﻿namespace TEMS.Business.Entities.ViewModel
{
    public class VenueViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
        public string Address { get; set; }
        public string Website { get; set; }
        public string ContactNo { get; set; }
    }
}
