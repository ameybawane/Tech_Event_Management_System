﻿namespace TEMS.Business.Entities.ViewModel
{
    public class SpeakerViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string Organisation { get; set; }
        public string LinkedinUrl { get; set; }
        public string TwitterHandle { get; set; }
    }
}
