﻿using TEMS.Business.Entities.ViewModel;

namespace TEMS.Business.Abstraction
{
    public interface ITalksDetail
    {
        Task AddTalksDetail(AddTalksDetail Data);
    }
}
